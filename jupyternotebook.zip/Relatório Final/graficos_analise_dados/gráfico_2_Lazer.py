import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Dados
dados = {
    'Raça': ['Amarela', 'Branca', 'Indígena', 'Parda', 'Preta'],
    'Diariamente': [0, 9, 1, 4, 3],
    'Mensalmente': [1, 20, 2, 14, 12],
    'Raramente': [1, 15, 3, 19, 13],
    'Semanalmente': [0, 25, 3, 16, 8]
}

df = pd.DataFrame(dados)

# Configurações
categorias = ['Diariamente', 'Mensalmente', 'Raramente', 'Semanalmente']
cores = ['royalblue', 'tomato', 'gold', 'mediumseagreen']  

# Gráfico de barras agrupadas
x = np.arange(len(df['Raça'])) 
largura = 0.2  

plt.figure(figsize=(10, 6))

for i, cat in enumerate(categorias):
    plt.bar(x + i * largura, df[cat], width=largura, label=cat, color=cores[i])

# Rótulos nas barras
for i, cat in enumerate(categorias):
    for j, valor in enumerate(df[cat]):
        plt.text(x[j] + i * largura, valor + 0.3, str(valor), ha='center', fontsize=8)

# Estética
plt.xticks(x + largura * 1.5, df['Raça'])
plt.ylabel("Quantidade")
plt.xlabel("Raça")
plt.title("Distribuição por Frequência e Raça", fontsize=14, weight='bold')
plt.legend(title="")
plt.grid(axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()

plt.show()
