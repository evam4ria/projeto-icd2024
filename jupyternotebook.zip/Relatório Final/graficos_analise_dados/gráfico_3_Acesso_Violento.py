import matplotlib.pyplot as plt
import numpy as np

# Dados
categorias = ['Amarela', 'Branca', 'Indígena', 'Preta/Parda']
valores = [1, 65, 8, 80]
cores = ['#4fc3f7', '#ef5350', '#fbc02d', '#43a047']
total = sum(valores)

# Função para mostrar valor absoluto + percentual
def make_autopct(values):
    def my_autopct(pct):
        val = int(round(pct * total / 100.0))
        return f'{pct:.1f}%\n({val})'
    return my_autopct

# Gráfico
fig, ax = plt.subplots(figsize=(9, 6))
wedges, texts, autotexts = ax.pie(
    valores,
    autopct=make_autopct(valores),
    startangle=90,
    colors=cores,
    pctdistance=0.7,
    textprops=dict(color="black", fontsize=10)
)

# Posicionamento das categorias
for i, (wedge, categoria) in enumerate(zip(wedges, categorias)):
    ang = (wedge.theta2 + wedge.theta1) / 2
    x = 1.5 * np.cos(np.deg2rad(ang))  
    y = 1.2 * np.sin(np.deg2rad(ang))
    ax.text(x, y, categoria, ha='center', va='center', fontsize=11)

# Título ajustado
plt.title("Evitou Frequentar Locais Por Medo de Violência", fontsize=14, weight='bold', pad=20)

# Ajuste de layout para evitar corte no topo
plt.subplots_adjust(top=0.85)
plt.tight_layout()
plt.show()
