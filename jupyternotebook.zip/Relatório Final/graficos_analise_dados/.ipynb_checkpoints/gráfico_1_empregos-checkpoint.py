import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Dados
categorias = ["Desempregados", "Trabalho Informal", "Trabalho Formal"]
quantidades = [78, 55, 34]

# Paleta pastel (como no gráfico anterior)
cores = sns.color_palette("pastel")[:3]

# Calculando porcentagens
total = sum(quantidades)
porcentagens = [q / total * 100 for q in quantidades]

# Rótulos com valor e porcentagem
labels = [f"{q} ({p:.1f}%)" for q, p in zip(quantidades, porcentagens)]

# Gráfico de pizza
plt.figure(figsize=(6, 6))
wedges, texts = plt.pie(
    quantidades,
    colors=cores,
    startangle=90,
    wedgeprops=dict(width=1.0, edgecolor='white')
)

# Adiciona rótulos ao lado das fatias
for i, (wedge, label) in enumerate(zip(wedges, labels)):
    ang = (wedge.theta2 + wedge.theta1) / 2
    x = 1.1 * np.cos(np.deg2rad(ang))
    y = 1.1 * np.sin(np.deg2rad(ang))
    plt.text(x, y, label, ha='center', va='center', fontsize=9)

# Legenda externa com categorias
plt.legend(categorias, title="", loc="center left", bbox_to_anchor=(1, 0.5))
plt.title("Distribuição por Situação de Trabalho", fontsize=14, weight='bold')

plt.tight_layout()
plt.show()
