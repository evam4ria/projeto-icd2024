import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Dados originais
dados = {
    "Religião": [
        "Agnóstica", "Ateu", "Bruxaria e Umbanda", "Candomblé", "Candomblé ", "candomblé-jurema", "Católica", "Cristã",
        "Discordianismo", "Espírita/Kardecista", "Evangélica", "Jurema", "Jurema sagrada", "Jurema Sagrada ", 
        "Jurema sagrada e candomblé ", "Não tenho religião", "Nao tenho religião ", "O amor", "Paganismo", 
        "Satanista ", "Umbanda", "Umbanda e jurema", "Wicca - Bruxaria Moderna"
    ],
    "Quantidade": [
        22, 9, 1, 16, 1, 1, 15, 1, 1, 7, 2, 1, 1, 1, 1, 74, 1, 1, 1, 1, 9, 1, 1
    ]
}

# Criando o DataFrame
df = pd.DataFrame(dados)
df["Religião"] = df["Religião"].str.strip().str.lower()

# Função de agrupamento
def agrupar_religiao(r):
    if "jurema" in r:
        return "Jurema"
    elif "umbanda" in r:
        return "Umbanda"
    elif "candomblé" in r:
        return "Candomblé"
    elif "não tenho" in r or "nao tenho" in r:
        return "Sem religião"
    elif "espírita" in r or "kardecista" in r:
        return "Espírita/Kardecista"
    elif "católica" in r:
        return "Católica"
    elif "evangélica" in r:
        return "Evangélica"
    elif "ateu" in r:
        return "Ateu"
    elif "agnóstica" in r:
        return "Agnóstica"
    else:
        return "Outros"

df["Grupo"] = df["Religião"].apply(agrupar_religiao)

# Agrupamento
df_grouped = df.groupby("Grupo")["Quantidade"].sum().sort_values(ascending=False).reset_index()

# Estilo
sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))

# Plot
plt.scatter(
    x=range(len(df_grouped)),
    y=df_grouped["Quantidade"],
    s=df_grouped["Quantidade"] * 50,
    alpha=0.7,
    c=sns.color_palette("pastel", len(df_grouped)),
    edgecolors="gray",
    linewidth=1
)

# Rótulos nas bolhas
for i, row in df_grouped.iterrows():
    plt.text(
        i, row["Quantidade"], str(row["Quantidade"]),
        ha='center', va='center', fontsize=9, weight='bold'
    )

# Estética
plt.title("Distribuição de Grupos Religiosos ", fontsize=14, weight='bold')
plt.xticks(ticks=range(len(df_grouped)), labels=df_grouped["Grupo"], rotation=45, ha='right', fontsize=9)
plt.xlabel("Grupo Religioso", fontsize=11)
plt.ylabel("Quantidade de Pessoas", fontsize=11)
plt.ylim(0, 90)
plt.grid(axis='y', linestyle='--', alpha=0.6)
plt.tight_layout(pad=2)

plt.show()

