import matplotlib.pyplot as plt

# Dados
categorias = ['Não', 'Sim']
valores = [59, 110]
cores = ['royalblue', 'royalblue'] 

# Gráfico de barras
plt.figure(figsize=(6, 4))
barras = plt.bar(categorias, valores, color=cores)

# Rótulos em cima das barras
for barra, valor in zip(barras, valores):
    plt.text(barra.get_x() + barra.get_width() / 2, valor + 2, str(valor),
             ha='center', va='bottom', fontsize=10, color='white', weight='bold')

# Estética
plt.ylabel("Quantidade")
plt.title("Sofreu Violência ao Tentar Acessar o Sistema de Saúde?", fontsize=14, weight='bold')
plt.ylim(0, 125)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()

plt.show()
